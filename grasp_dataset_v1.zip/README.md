# Grasp dataset v1 — complete data download

This archive contains all six frozen data/v1 files and docs/DATASET.md,
which explains the features, units, labels, grouping, splits and provenance.
The CSV contains 3,840 real simulated grasp-and-hold trials.

Keep the data/v1 directory intact. The CSV and fixed split/CV assignments
are unchanged from the course repository. No simulation videos, models,
older datasets or new labels are mixed into this data-only export.
PACKAGE_MANIFEST.json contains SHA256 hashes for every payload file.

Training code and the reproducible environment are available at:
https://github.com/youseihuayu-wonderful/intelligent-grasping-course-project
From that checkout, validate this extracted dataset with:
uv run --locked python baseline.py --data-dir /path/to/extracted/data/v1 --validate-only

The historical test partition has already been published and inspected.
It is not a new blind final test and must not be used for tuning.

## Simulation demo

The separate recorded simulation can be viewed online at:
https://github.com/youseihuayu-wonderful/intelligent-grasping-course-project#simulation-demo
